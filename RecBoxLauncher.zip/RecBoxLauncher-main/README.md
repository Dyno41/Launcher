# RecBoxLauncher
This is all the data needed for RecBox to download server updates.
